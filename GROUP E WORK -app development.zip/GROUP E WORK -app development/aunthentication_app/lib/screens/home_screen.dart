import 'package:flutter/material.dart';
import 'package:aunthentication_app/models/user_model.dart';
import 'package:aunthentication_app/widgets/custom_drawer.dart';
import 'package:aunthentication_app/widgets/member_list_item.dart';
import 'package:aunthentication_app/widgets/product_grid_item.dart';

class HomeScreen extends StatelessWidget {
  final User user;
  final List<User> members = [
    User(name: 'SSEKITTO ABDUL', email: 'ssekittoabdul22@gmail.com'),
    User(name: 'TUSIIME PRINCE', email: 'princetusiime@gmail.com'),
    User(name: 'MAWA DAVID', email: 'davidmawa@gmail.com'),
    User(name: 'NAKACWA BRENDA FAITH', email: 'brendanakacwa34@gmail.com'),
    User(name: 'MUTONYI DOREEN', email: 'doreenmutonyi@gmail.com'),
  ];

  // List of products (emoji + title)
  final List<Map<String, String>> products = [
    {"emoji": "📱", "title": "Smartphones"},
    {"emoji": "💻", "title": "Laptops"},
    {"emoji": "⌚", "title": "Digital Watches"},
    {"emoji": "👟", "title": "Shoes"},
    {"emoji": "🎧", "title": "Headphones"},
    {"emoji": "📷", "title": "Cameras"},
  ];

  HomeScreen({super.key, required this.user});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Home')),
      drawer: CustomDrawer(user: user),
      body: Container(
        color: const Color.fromARGB(255, 70, 160, 202), // Light blue background
        child: Column(
          children: [
            // Members List (Horizontal Scroll)
            SizedBox(
              height: 160,
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                itemCount: members.length,
                itemBuilder:
                    (context, index) => MemberListItem(user: members[index]),
              ),
            ),
            Divider(),
            // Products Grid View
            Expanded(
              child: GridView.builder(
                padding: EdgeInsets.all(10),
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, // 2 items per row
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                  childAspectRatio: 1.2, // Adjust item aspect ratio
                ),
                itemCount: products.length,
                itemBuilder:
                    (context, index) => ProductGridItem(
                      emoji: products[index]["emoji"]!,
                      title: products[index]["title"]!,
                    ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
