class User {
  final String name;
  final String email;
  String? profileImageUrl;

  User({required this.name, required this.email, this.profileImageUrl});

  User copyWith({String? name, String? email, String? profileImageUrl}) {
    return User(
      name: name ?? this.name,
      email: email ?? this.email,
      profileImageUrl: profileImageUrl ?? this.profileImageUrl,
    );
  }
}
